import pytest

from app import create_app
from app.repository import InMemoryProductRepository


@pytest.fixture
def client():
    app = create_app(InMemoryProductRepository())
    app.config.update(TESTING=True)
    return app.test_client()


def product_payload(**overrides):
    product = {
        "product_id": "SKU-001",
        "name": "Coffee Beans",
        "category": "Grocery",
        "price": "12.50",
        "quantity": 8,
    }
    product.update(overrides)
    return product


def test_product_creation_and_search(client):
    response = client.post("/products", json=product_payload())

    assert response.status_code == 201
    assert response.json["quantity"] == 8
    assert client.get("/products?query=coffee").json[0]["product_id"] == "SKU-001"


def test_stock_increases_and_decreases(client):
    client.post("/products", json=product_payload())

    assert client.post("/products/SKU-001/stock/increase", json={"amount": 4}).json["quantity"] == 12
    assert client.post("/products/SKU-001/stock/decrease", json={"amount": 7}).json["quantity"] == 5


def test_stock_cannot_fall_below_zero(client):
    client.post("/products", json=product_payload(quantity=2))

    response = client.post("/products/SKU-001/stock/decrease", json={"amount": 3})

    assert response.status_code == 409
    assert "below zero" in response.json["error"]


def test_inventory_value(client):
    client.post("/products", json=product_payload(price="12.50", quantity=4))
    client.post("/products", json=product_payload(product_id="SKU-002", price="3.00", quantity=2))

    assert client.get("/inventory/value").json == {"inventory_value": "56.00"}


def test_unknown_product_and_duplicate_are_handled(client):
    assert client.get("/products/missing").status_code == 404
    client.post("/products", json=product_payload())
    assert client.post("/products", json=product_payload()).status_code == 409


def test_negative_price_and_quantity_are_rejected(client):
    assert client.post("/products", json=product_payload(price=-1)).status_code == 400
    assert client.post("/products", json=product_payload(quantity=-1)).status_code == 400